%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Second Order Upwind Scheme
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
clear all
close all

Omega = [0, 1]; T = 1;                              % 一维求解区域Omega;时间[0,T]                  
D = 10^-1; v = 1;                                   % ft-D·fxx+v·fx=0   
f=@(x, t) 1 + exp(-pi^2 * t/10) .* sin(pi * (x-t)); % 精确解

alpha = 1/2;    % 用于泰勒展开的参数
N=20;
H = (Omega(2)-Omega(1))/N;
Tau = T/N; % 时间也分成N份
X = linspace(Omega(1),Omega(2), N+1); % 将剖分后的坐标值存在行向量中


Mass = sparse(N+1, N+1); % 时间导数项
A = sparse(N+1, N+1);    % 扩散项
C = sparse(N+1, N+1);    % 对流项
% 时间导数项
for i=2:N
    if i==2
    Mass(i,i-1)=H/6* (H/2*( -alpha/H )+1)+2*H/6* H/2*(-(1-alpha)/H);% u1
    Mass(i,i)  =H/6* (H/2*(1-alpha)/H+5)-H/6* H/2*(-(1-alpha)/H);% u2
    Mass(i,i+1)=H/6* H/2*alpha/H;% u3    
    else
    Mass(i,i-2)=H/6* H/2*(-(1-alpha)/H);
    Mass(i,i-1)=H/6* (H/2*( -alpha/H )+1);
    Mass(i,i)  =H/6* (H/2*(1-alpha)/H+5);
    Mass(i,i+1)=H/6* H/2*alpha/H;  
    end
end
mm = full(Mass);
% 扩散项(不带负号)
for i=2:N
    A(i,i)=D*Tau*(-2/H);
    A(i,i-1)=D*Tau*(1/H);
    A(i,i+1)=D*Tau*(1/H);
end
aa = full(A);
% 对流项
for i=2:N
    if i==2
    C(i,i)  =v*Tau* (1+H/2*((1-alpha)/H-2*alpha/H))-v*Tau* H/2*(1-alpha)/H;% u2 c2-c0
    C(i,i-1)=v*Tau* (-1+H/2*( -2*(1-alpha)/H+alpha/H) )+2*v*Tau* H/2*(1-alpha)/H;% u1 2c0+c1
    C(i,i+1)=v*Tau* (H/2*alpha/H);% u3 系数不变
    else
    C(i,i)  =v*Tau* (1+H/2*((1-alpha)/H-2*alpha/H));
    C(i,i-1)=v*Tau* (-1+H/2*( -2*(1-alpha)/H+alpha/H) );
    C(i,i+1)=v*Tau* (H/2*alpha/H);
    C(i,i-2)=v*Tau* H/2*(1-alpha)/H;
    end
end
cc = full(C);
S = Mass+(-A)+C;ss = full(S);

% 处理边界条件 上一时间层作为已知计算下一时间层
S(1,1)=1;S(end,end)=1;
F=ones(N+1,N+1);% 创建F用来存时间层t=0,t=1,..,t=N+1的边界条件
F(2:end-1,:)=0;
for i=1:N+1
F(1,i)=f(Omega(1),Tau*(i-1));
F(end,i)=f(Omega(end),Tau*(i-1));% 由f计算Dirichlet边界条件
end
% ff = full(F);

Uh=sparse(N+1,N+1);% 时间层递推计算数值解.按列存放在矩阵中
Uh(:,1) = f(X,0)'; % t=0的数值解可由精确解f直接计算.存在Uh的第一列
% RightHand=Mass*Uh0+F(:,2);% 由t=0算t=1
% Uh(:,2)=S\RightHand;% t=1的数值解存在Uh的第2列
uu=full(Uh);
for i = 1:N
    Uh(:,i+1)=S\(Mass*Uh(:,i)+F(:,i+1));
end
uu=full(Uh);
% Uh1_real=f(X,Tau)';