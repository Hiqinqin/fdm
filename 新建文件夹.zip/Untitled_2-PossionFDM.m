%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 对流扩散方程的新迎风有限体积法
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
clear all
close all

Omega_x = [0, 1];Omega_y = [0, 1];
N_x=5;N_y=5;
X = linspace(Omega_x(1),Omega_x(2), N_x+1);
Y = linspace(Omega_x(1),Omega_x(2), N_y+1);
[XX,YY]=meshgrid(X,Y);% XX是每行的横坐标 YY是每行的纵坐标
length=(N_x+1)*(N_y+1);
x=reshape(XX,length,1);
y=reshape(YY,length,1);
% f=2*pi^2*sin(pi*x).*sin(pi*y);
% u=sin(pi*x).*sin(pi*y);
u = exp(x+y);
f = -2*exp(x+y);

A=sparse(length,length);
F=sparse(length,1);
for i = 1:N_x+1
    for j =1:N_y+1
        idx = (i-1)*(N_y+1)+j;
        if  2<=i && i<=N_x && 2<=j && j<=N_y
            A(idx,idx) = 2*(N_x/N_y)+2*(N_y/N_x);% u_{i,j}
            A(idx,idx-1) = -N_y/N_x;% u_{i,j-1}
            A(idx,idx+1) = -N_y/N_x;% u_{i,j+1}
            A(idx,idx+N_y+1) = -N_x/N_y;% u_{i+1,j}
            A(idx,idx-N_y-1) = -N_x/N_y;% u_{i-1,j}
            F(idx,1)=f(idx,1)*1/(N_x*N_y);
        else
            A(idx,idx)=1;
            F(idx,1)=u(idx,1);
        end           
    end
end
aa = full(A);
Uh=A\F;
e=max(abs(u-Uh));